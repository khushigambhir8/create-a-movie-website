import fresh_tomatoes
import media
a_quiet_place = media.Movie("A Quiet Place",#show title of movie
                            "If they hear you, they hunt you.",#show storyline of movie
                            "https://i.pinimg.com/originals/2a/21/e4/2a21e432b86be3d64be18a0969e4ce67.jpg",#show poster of movie
                            "https://www.youtube.com/watch?v=p9wE8dyzEJE")#show trailer of movie
a_star_is_born = media.Movie("A Star Is Born",
                 "A cynical has-been rock star falls in love with an upcoming songstress.",
                 "http://cdn.collider.com/wp-content/uploads/2018/06/a-star-is-born-poster-bradley-cooper-600x600.jpg",
                 "https://www.youtube.com/watch?v=nSbzyEJ8X9E")

truth_or_dare = media.Movie("Truth or Dare",
                            "A harmless game of Truth or Dare among friends turns deadly",
                           "https://philrobertsart.files.wordpress.com/2012/08/truthdarexo-phil-roberts.jpg?w=692",
                            "https://www.youtube.com/watch?v=Cgnk3MLw9TM")
red_sparrow = media.Movie("Red Sparrow",
                        "Prima ballerina Dominika Egorova suffers an injury that ends her career and then soon turns to sparrow school",
                          "http://www.joblo.com/posters/images/full/Red-Sparrow-poster-2.jpg",
                          "https://www.youtube.com/watch?v=ZQUBjoGm1ls")
the_godfather = media.Movie("The Godfather",
                            "Don Vito Corleone, head of a mafia family, decides to hand over his empire to his youngest son Michael.",
                            "https://m.media-amazon.com/images/M/MV5BM2MyNjYxNmUtYTAwNi00MTYxLWJmNWYtYzZlODY3ZTk3OTFlXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg",
                            "https://www.youtube.com/watch?v=sY1S34973zA")
                                      
drive = media.Movie("Drive",
                    "A stuntman and getaway driver falls in love with Irene who is married to a criminal",
                    "https://img.posterlounge.co.uk/images/wbig/poster-drive-ryan-gosling-movie-inspired-art-1601058.jpg",
                    "https://www.youtube.com/watch?v=KBiOF3y1W0Y")
                                   
#print(red_sparrow.storyline)
movie = [a_quiet_place, a_star_is_born, truth_or_dare, red_sparrow , the_godfather, drive]
fresh_tomatoes.open_movies_page(movie)
